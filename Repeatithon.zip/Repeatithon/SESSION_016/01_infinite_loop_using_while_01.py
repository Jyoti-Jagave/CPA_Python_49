print('start of program')
i_jj = 0
while True:
    i_jj = i_jj + 1_jj
    print(i_jj, 'Hello')
    a_jj = 10
    b_jj = 20
    c_jj = a_jj + b_jj
print('end of program') # control flow will never reach here
