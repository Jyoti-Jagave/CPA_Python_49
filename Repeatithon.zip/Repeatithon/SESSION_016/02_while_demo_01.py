print('start of program')
print('start of while loop:')
i_jj = 1
while i_jj <= 5:
       print('repeatition number:', i_jj)
       i_jj = i_jj + 1
print('end of while loop')
print('value of i_jj after while loop ends:', i_jj)
print('end of program')
