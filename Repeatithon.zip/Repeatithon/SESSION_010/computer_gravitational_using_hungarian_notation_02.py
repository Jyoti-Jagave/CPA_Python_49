f1MassOfObjectOneInKgs = float(input('Enter mass of object 1 in kgs:'))
f1MassOfObjectTwoInKgs = float(input('Enter mass of object 2 in kgs:'))
f1DistanceBetweenObjectsInMetes = float(input('Enter distance between objects in metes:'))
f1UniversalConstantOfgravitational = 6.67 * (10 ** -11)
f1ForceOfGravitationInNewton = (f1UniversalconstantOfGravitational * fMassOfObjectOneInKgs *
                                f1MasOfObjectTwoInKgs) / (f1DistanceBetweenObjectsInMetes ** 2)
print("gravitational ForceL:", f1ForceOfGravitationalInNewton, 'Newton')
