print('start of program')
i_jj = 0
while i_jj < 5:
    print('Value of i_jj:', i_jj)
    i_jj = i_jj + 1
print('End of while statement')
print('Value of i_jj at the end:', i_jj)
print('End of program')
