# Create list list L1_jj:
L1_jj = [10, 20, 30, 40, 50] 
# Without loop each individual access will require a separate
# statement
# Access element at index 0
n_jj = L1_jj[0]
print('Element at index 0:', n_jj)

# Access element at index 1
n_jj = L1_jj[1]
print('Element at index 1:', n_jj)

# Access element at index 2
n_jj = L1_jj[2]
print('Element at index 2:', n_jj)

# Access element at index 3
n_jj = L1_jj[3]
print('Element at index 3:', n_jj) 

# Access element at index 4
n_jj = L1_jj[4]
print('Element at index 4:', n_jj)
#-----------------------------------
print('Accessing and printing list values using while loop:')

# Write loop variable initialization, loop variable condition
# and loop variable modification so that the loop variable
# goes through the valid index range
i_jj = 0 # initialize loop variable with the first valid index
while i_jj < len(L1_jj):
    n_jj = L1_jj[i_jj]
    print('Element at index:', i_jj, 'is:', n_jj)
    i_jj = i_jj + 1 
