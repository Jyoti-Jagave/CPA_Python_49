# Goal: Print all even numbers between 1 to 10

print('start of program')
i_jj = 1
while i_jj <= 10:
     if i_jj % 2 == 0:
         print(i_jj)
     i_jj = i_jj + 1
print('End of While: End Value (i_jj):', i_jj)
print('End of program')
