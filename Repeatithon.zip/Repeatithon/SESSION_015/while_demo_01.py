# This program illustrates an infinite loop
# You must press ctrl + c to terminate the program

while True:
    print('Hello, CPA Python 49 batch')
    a_jj = 10
    b_jj = 20
    c_jj = a_jj + b_jj
    print('Addition of:', a_jj, 'and', b_jj, 'is', c_jj)
