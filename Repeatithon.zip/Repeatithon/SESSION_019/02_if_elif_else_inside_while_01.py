print('start of program')
i_jj = -5
while i_jj <= 5:
    if i_jj > 0:
        print(i_jj, 'is positive')
    elif i_jj < 0:
        print(i_jj, 'is negative')
    else:
        print(i_jj, 'is zero')
    i_jj = i_jj + 1
print('End of while loop. End value of i_jj:', i_jj)
print('End of program') 
        
