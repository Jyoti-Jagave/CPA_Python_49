print('Start of program')
i_jj = 1
while i_jj <= 10:
    if i_jj % 2 == 0:
        print(i_jj, 'is an even number')
    else:
        print(i_jj, 'is an odd number')
    i_jj = i_jj + 1
print('End of while loop: End value of i_jj:', i_jj)
print('End of program') 
