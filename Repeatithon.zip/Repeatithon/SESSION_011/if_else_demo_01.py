print('start of program')
n_jj = int(input('Enter an integer:'))
if n_jj > 0:
    print(n_jj, "is a positive number")
else:
    print(n_jj, "is either a nagative number or zero")
print('end of program')
