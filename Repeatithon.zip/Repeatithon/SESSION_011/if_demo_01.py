print('start of program')
n_jj = int(input('enter an integers:'))
if n_jj > 0:
    print(n_jj, 'is a positive number')
print('end of program')
