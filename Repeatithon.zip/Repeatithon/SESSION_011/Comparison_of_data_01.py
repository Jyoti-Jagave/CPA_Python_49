m_jj = int(input("Enter an integer:"))
n_jj = int(input("Enter an integer:"))

result_jj = m_jj > n_jj;
print("result of m_jj > n_jj is:", result_jj)

result_jj = m_jj >= n_jj;
print("result of m_jj >= n_jj is:", result_jj)

result_jj = m_jj < n_jj;
print("result of m_jj < n_jj is:", result_jj)

result_jj = m_jj <= n_jj;
print("result of m_jj <= n_jj is:", result_jj)

result_jj = m_jj == n_jj;
print("result of m_jj == n_jj is:", result_jj)

result_jj = m_jj != n_jj;
print("result of m_jj != n_jj is:", result_jj)
