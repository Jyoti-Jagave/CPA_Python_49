Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # SESSION 010 : Repeatithon 01
>>> # create int 100 and name it as 'a'
>>> a = 100
>>> # create integer 5 and name it as 'numberOfRepeatitihon'
>>> numberOfRepeatithons = 5
>>> # create an integer 120 and name it as NumberOfSessions
>>> NumberOfRepeatithons = 125
>>> # create integer 145 and name it as number_of_admissions
>>> number_of_admisssions = 145
>>> # create an integer 2 and name it as durationInHours
>>> durationInHours = 2
>>> a = 100
>>> a = 100
>>> a = 100
>>> a = 100
>>> a = 100
>>> # a = 100, 5 times done
>>> numberOfrepeatithon = 5
>>> numberOfRepeatithons = 5
>>> numberOfRepeatithon = 5
>>> numberOfRepeatithon = 5
>>> numberOfRepeatithion = 5
>>> numberOfRepeatithon = 5
>>> # numberOfRepeatithons = 5, 5 times, doneiNumberOfSession = 125
>>> iNumberOfSession = 125
>>> iNumberOfSession = 125
>>> iNumberOfSessionn = 125
>>> iNumberOfSession = 125
>>> iNumberOfSession = 125
>>> # iNumberOfSessions = 125, 5 times, done
>>> number_of_admissions = 145
>>> number_of_admissions = 145
>>> number_of_admissions = 145
>>> number_of_admissions = 145
>>> number_of_admissions = 145
>>> # number_of_admissions = 145, 5 time, done
>>> durationInHours = 2
>>> durationInHours = 2
>>> durationInHours = 2
>>> durationInHours = 2
>>> durationInHours = 2
    # durationInHours = 2, 5 times done
